(function () {
	var addButton = document.getElementById('add'),
		output = document.getElementById('output');

	function printListElement(value) {
		var newElement = document.createElement('li');
		
		newElement.className = 'list-group-item';
		newElement.innerHTML = value;

		output.appendChild(newElement);
	}
})();