$(document).ready(function () {
	var $a = $('#input-a'),
		$b = $('#input-b'),
		$calculate = $('#calculate');

	$calculate.click(function () {
		$('#result-1').val($.add($a.val(), $b.val()));

		$('#result-2').val($.sub($a.val(), $b.val()));

		$('#result-3').val($.addSquare($a.val(), $b.val()));

		$('#result-4').val($.pow($a.val(), $b.val()));
	});
});