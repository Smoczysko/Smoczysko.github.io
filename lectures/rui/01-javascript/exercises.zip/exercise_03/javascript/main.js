(function () {
	var foo = 1;
	
	function inner() {
		function foo() {
			foo = 5;
		}

		foo();

		document.getElementById('input-1').value = foo;

		foo = 10;

		document.getElementById('input-2').value = foo;
	}
	inner();

	document.getElementById('input-3').value = foo;
})();