(function () {
	var foo = 1;
	
	function inner() {
		foo = 10;
		
		document.getElementById('input-1').value = foo;

		return;

		function foo() {};
	}
	inner();

	document.getElementById('input-2').value = foo;
})();