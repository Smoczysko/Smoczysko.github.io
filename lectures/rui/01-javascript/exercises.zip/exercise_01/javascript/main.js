for (var i = 1; i < 6; i++) {
	var temp = i;

	setTimeout(function() {
		var inputElement = document.getElementById('input-' + i);
		inputElement.value = i;
	}, 1000);
}